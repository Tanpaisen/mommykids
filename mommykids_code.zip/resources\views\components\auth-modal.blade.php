<!-- Modal Đăng nhập Client -->
<div id="loginModal" class="fixed inset-0 bg-black/60 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl flex flex-col md:flex-row relative">
        
        <!-- Nút Đóng Modal -->
        <button onclick="closeLoginModal()" class="absolute top-3 right-4 text-gray-400 hover:text-gray-600 text-2xl font-bold z-10">&times;</button>

        <!-- Bên trái: Banner Đỏ -->
        <div class="md:w-1/2 bg-rose-600 p-6 text-white flex flex-col items-center justify-center text-center relative overflow-hidden">
            <h3 class="text-2xl font-black mb-1">100%</h3>
            <p class="text-xl font-bold uppercase tracking-wide">Hàng Chính Hãng</p>
            <div class="mt-4 w-40 h-56 bg-rose-500 rounded-2xl border-4 border-white/20 shadow-inner flex items-center justify-center p-2">
                 <span class="text-xs text-rose-100 font-semibold">MommyKids App</span>
            </div>
        </div>

        <!-- Bên phải: Form Đăng nhập Email OTP & Social -->
        <div class="md:w-1/2 p-6 md:p-8 flex flex-col justify-center">
            <div class="text-center mb-6">
                <h2 class="text-2xl font-bold text-rose-600">ĐĂNG NHẬP</h2>
                <p class="text-xs text-gray-500 mt-1">Hãy trở thành thành viên để không bỏ lỡ các ưu đãi, giảm giá và voucher dành riêng cho bạn</p>
            </div>

            <!-- Thông báo lỗi/thành công -->
            <div id="modalAlert" class="hidden mb-3 p-2 text-xs rounded-xl text-center"></div>

            <form id="otpLoginForm" onsubmit="handleVerifyOtp(event)" class="space-y-4">
                @csrf
                <!-- Nhập Email & Nút gửi OTP -->
                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-1">Địa chỉ Email *</label>
                    <div class="flex gap-2">
                        <input type="email" id="clientEmail" required placeholder="Vui lòng nhập Email của Bạn" 
                               class="w-full text-xs px-3 py-2.5 rounded-xl border border-gray-300 focus:border-rose-500 outline-none">
                        <button type="button" id="btnSendOtp" onclick="handleSendOtp()" 
                                class="bg-gray-100 hover:bg-gray-200 text-rose-600 text-xs font-bold px-3 py-2 rounded-xl whitespace-nowrap transition border border-gray-200">
                            Gửi OTP
                        </button>
                    </div>
                </div>

                <!-- 6 ô nhập mã OTP -->
                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-1">Mã xác thực *</label>
                    <div class="grid grid-cols-6 gap-2" id="otpInputs">
                        <input type="text" maxlength="1" class="otp-box w-full h-10 text-center font-bold text-lg border border-gray-300 rounded-xl focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none">
                        <input type="text" maxlength="1" class="otp-box w-full h-10 text-center font-bold text-lg border border-gray-300 rounded-xl focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none">
                        <input type="text" maxlength="1" class="otp-box w-full h-10 text-center font-bold text-lg border border-gray-300 rounded-xl focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none">
                        <input type="text" maxlength="1" class="otp-box w-full h-10 text-center font-bold text-lg border border-gray-300 rounded-xl focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none">
                        <input type="text" maxlength="1" class="otp-box w-full h-10 text-center font-bold text-lg border border-gray-300 rounded-xl focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none">
                        <input type="text" maxlength="1" class="otp-box w-full h-10 text-center font-bold text-lg border border-gray-300 rounded-xl focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none">
                    </div>
                </div>

                <!-- Checkbox Điều khoản -->
                <div class="flex items-start gap-2 pt-1">
                    <input type="checkbox" id="terms" required class="mt-0.5 rounded text-rose-600 focus:ring-rose-500">
                    <label for="terms" class="text-[10px] text-gray-500 leading-tight">
                        Tôi đã đọc và đồng ý với các <a href="#" class="text-rose-600 underline">Điều khoản sử dụng</a> và <a href="#" class="text-rose-600 underline">Chính sách bảo mật</a> của MommyKids
                    </label>
                </div>

                <!-- Nút Đăng Nhập OTP -->
                <button type="submit" class="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-full text-sm shadow-md transition">
                    ĐĂNG NHẬP
                </button>
            </form>

            <!-- Khối Đăng Nhập Mạng Xã Hội -->
            <div class="mt-4 pt-3 border-t border-gray-100 text-center">
                <p class="text-[11px] text-gray-400 font-medium mb-2.5">Hoặc đăng nhập bằng</p>
                
                <a href="{{ route('auth.facebook') }}" 
                   class="flex items-center justify-center gap-2 py-2.5 px-4 bg-[#1877F2] text-white rounded-xl hover:bg-blue-700 transition text-xs font-bold shadow-sm w-full">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                    Đăng nhập bằng Facebook
                </a>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript Xử lý AJAX Không Load Trang -->
<script>
    function openLoginModal() { document.getElementById('loginModal').classList.remove('hidden'); }
    function closeLoginModal() { document.getElementById('loginModal').classList.add('hidden'); }

    function showAlert(msg, isSuccess) {
        const el = document.getElementById('modalAlert');
        el.className = `mb-3 p-2 text-xs rounded-xl text-center ${isSuccess ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`;
        el.innerText = msg;
        el.classList.remove('hidden');
    }

    // Gói việc khởi tạo OTP vào DOMContentLoaded để không bị tràn biến ra ngoài
    document.addEventListener('DOMContentLoaded', function() {
        const otpBoxes = document.querySelectorAll('.otp-box');
        otpBoxes.forEach((box, idx) => {
            box.addEventListener('input', (e) => {
                if (e.target.value && idx < otpBoxes.length - 1) otpBoxes[idx + 1].focus();
            });
            box.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && !e.target.value && idx > 0) otpBoxes[idx - 1].focus();
            });
        });
    });

    // AJAX 1: Gửi OTP
    async function handleSendOtp() {
        const email = document.getElementById('clientEmail').value;
        if (!email) return showAlert('Vui lòng nhập Email!', false);

        const btn = document.getElementById('btnSendOtp');
        btn.disabled = true;
        btn.innerText = 'Đang gửi...';

        try {
            const res = await fetch('{{ route("api.send-otp") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ email })
            });
            const data = await res.json();
            showAlert(data.message, data.success);

            if (data.success) {
                let timer = 60;
                const interval = setInterval(() => {
                    btn.innerText = `Thử lại (${timer--}s)`;
                    if (timer < 0) {
                        clearInterval(interval);
                        btn.innerText = 'Gửi OTP';
                        btn.disabled = false;
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = 'Gửi OTP';
            }
        } catch (err) {
            showAlert('Lỗi kết nối máy chủ!', false);
            btn.disabled = false;
            btn.innerText = 'Gửi OTP';
        }
    }

    // AJAX 2: Xác thực & Đăng nhập không reload trang
    async function handleVerifyOtp(e) {
        e.preventDefault();
        const email = document.getElementById('clientEmail').value;
        
        // Query trực tiếp các ô OTP lúc submit để lấy giá trị (Tránh lỗi đụng biến)
        let otp = '';
        document.querySelectorAll('.otp-box').forEach(box => otp += box.value);

        if (otp.length < 6) return showAlert('Vui lòng nhập đủ 6 số OTP!', false);

        try {
            const res = await fetch('{{ route("api.verify-otp") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ email, otp })
            });
            
            // Xử lý nếu Server ném ra lỗi 500
            if (res.status === 500) {
                return showAlert('Lỗi Server: Vui lòng kiểm tra lại laravel.log', false);
            }

            const data = await res.json();

            if (data.success) {
                showAlert('Đăng nhập thành công!', true);
                setTimeout(() => {
                    closeLoginModal();
                    window.location.reload(); // Cập nhật Header thành trạng thái đã đăng nhập
                }, 800);
            } else {
                showAlert(data.message, false);
            }
        } catch (err) {
            showAlert('Lỗi xác thực OTP!', false);
        }
    }
</script>